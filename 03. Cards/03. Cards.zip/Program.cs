﻿


using _03._Cards;

string[] dec = Console.ReadLine().Split(", ",StringSplitOptions.RemoveEmptyEntries).ToArray();
List<Card> cards = new List<Card>();

foreach (var item in dec)
{
    string[] currentCard = item.Split(" ");
    string face = currentCard[0];
    string suit = currentCard[1];
   cards.Add(CreateCard(face, suit));
}


Card CreateCard(string face, string suit)
{
    try
    {
        Card card = new Card(face, suit);
        return card;
    }
    catch (InvalidOperationException ex)
    {
        Console.WriteLine(ex.Message);
        return null;
    }
}
Console.WriteLine(string.Join(" ",cards));