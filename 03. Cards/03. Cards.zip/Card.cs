﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03._Cards
{
    public class Card
    {
        private readonly string[] validFaces = new string[]
        {
            "2","3","4","5","6","7","8","9","10","J","Q","K","A"
        };
        private readonly Dictionary<string,string> validSuits = new Dictionary<string, string>()
        {

            {"S","♠"},
            {"H","♥"},
            {"D","♦"},
            {"C","♣"}
        };
       private string face;
        private string suit;

        public Card(string face, string suit)
        {
            Face = face;
            Suit = suit;
        }

        public string Face 
        {
            get => face;
            set
            {
                if(!validFaces.Contains(value))
                {
                    throw new InvalidOperationException("Invalid card!");
                }
                
                face = value;
            }
        }
        public string Suit
        { 
            get => suit;
            set
            {
                if (!validSuits.ContainsKey(value))
                {
                    throw new InvalidOperationException("Invalid card!");
                }
                string currentSuit = validSuits[value];
                suit = currentSuit;
            }
        }

        public override string ToString()
        {
            return $"[{Face}{Suit}]";
        }
    }
}
